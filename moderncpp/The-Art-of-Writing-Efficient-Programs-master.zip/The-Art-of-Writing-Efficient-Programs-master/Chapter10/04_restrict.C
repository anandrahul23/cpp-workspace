void do_work(int& a, int& b, int& x) {
    a += x;
    b += x;
}
