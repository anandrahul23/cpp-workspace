void g(const int& y);
bool f(int x) {
    g(x + 1);
    return true;
}
