extern void g();
int f(int* p) {
    g();
    return *p;
}

