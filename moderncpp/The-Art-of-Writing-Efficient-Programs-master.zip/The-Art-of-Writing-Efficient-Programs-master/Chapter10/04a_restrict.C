void do_work(int& a, int& b, int& x) {
    const int y = x;
    a += y;
    b += y;
}
