#include <iostream>

using namespace std;

int i = 1;

int main() {
    cout << "Before" << endl;
    while (i) {}
    cout << "After" << endl;
}
