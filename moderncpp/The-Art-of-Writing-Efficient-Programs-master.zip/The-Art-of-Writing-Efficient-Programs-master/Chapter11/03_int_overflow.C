bool f(int i) { return i + 1 > i; }
bool g(int i) { return true; }
bool f(unsigned int i) { return i + 1 > i; }
