int f(int* p) {
    if (p) ++(*p);
    return *p;
}

