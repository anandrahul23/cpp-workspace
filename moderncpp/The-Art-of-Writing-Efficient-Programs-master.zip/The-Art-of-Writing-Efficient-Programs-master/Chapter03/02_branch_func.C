unsigned long f1(unsigned long p1, unsigned long p2) { return p1 - p2; }
unsigned long f2(unsigned long p1, unsigned long p2) { return p1 * p2; }
