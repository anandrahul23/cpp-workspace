int f(int* p) {
    ++(*p);
    return *p;
}

